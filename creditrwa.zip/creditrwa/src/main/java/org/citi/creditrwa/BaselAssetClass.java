package org.citi.creditrwa;

public class BaselAssetClass {

	String sumNotationalAmountFinal;
	String sumPreMitigationAmountFinal;

	public String getSumNotationalAmountFinal() {
		return sumNotationalAmountFinal;
	}

	public void setSumNotationalAmountFinal(String sumNotationalAmountFinal) {
		this.sumNotationalAmountFinal = sumNotationalAmountFinal;
	}

	public String getSumPreMitigationAmountFinal() {
		return sumPreMitigationAmountFinal;
	}

	public void setSumPreMitigationAmountFinal(String sumPreMitigationAmountFinal) {
		this.sumPreMitigationAmountFinal = sumPreMitigationAmountFinal;
	}

}
