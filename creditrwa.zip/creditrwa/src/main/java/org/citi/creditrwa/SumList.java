package org.citi.creditrwa;

public class SumList {
	
	String sumNotationalAmount;
	String sumPreMitigationAmount;
	
	public String getSumNotationalAmount() {
		return sumNotationalAmount;
	}
	public void setSumNotationalAmount(String sumNotationalAmount) {
		this.sumNotationalAmount = sumNotationalAmount;
	}
	public String getSumPreMitigationAmount() {
		return sumPreMitigationAmount;
	}
	public void setSumPreMitigationAmount(String sumPreMitigationAmount) {
		this.sumPreMitigationAmount = sumPreMitigationAmount;
	}
	
}