package org.citi.creditrwa;

public class CreditRWAVO {

	public String riskWeight;
	
	public String notationalAmount;
	
	public String premitigationEAD;
	
	public String uncoveredEAD;
	
	public String baselAssetClass;
	
	public String bs_obs_otc;

	public String getRiskWeight() {
		return riskWeight;
	}

	public void setRiskWeight(String riskWeight) {
		this.riskWeight = riskWeight;
	}

	public String getNotationalAmount() {
		return notationalAmount;
	}

	public void setNotationalAmount(String notationalAmount) {
		this.notationalAmount = notationalAmount;
	}

	public String getPremitigationEAD() {
		return premitigationEAD;
	}

	public void setPremitigationEAD(String premitigationEAD) {
		this.premitigationEAD = premitigationEAD;
	}

	public String getUncoveredEAD() {
		return uncoveredEAD;
	}

	public void setUncoveredEAD(String uncoveredEAD) {
		this.uncoveredEAD = uncoveredEAD;
	}

	public String getBaselAssetClass() {
		return baselAssetClass;
	}

	public void setBaselAssetClass(String baselAssetClass) {
		this.baselAssetClass = baselAssetClass;
	}

	public String getBs_obs_otc() {
		return bs_obs_otc;
	}

	public void setBs_obs_otc(String bs_obs_otc) {
		this.bs_obs_otc = bs_obs_otc;
	}
	
}
