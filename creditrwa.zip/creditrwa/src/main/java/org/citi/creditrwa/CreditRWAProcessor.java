package org.citi.creditrwa;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

public class CreditRWAProcessor {

	public static void main(String[] args) {

		List<CreditRWAVO> inputlist = new ArrayList<CreditRWAVO>();

		Iterator<CreditRWAVO> itr = inputlist.iterator();

		Map<String, SumList> map = new HashMap<String, SumList>();

		SumList sumList = new SumList();

		while (itr.hasNext()) {

			CreditRWAVO vo = itr.next();

			if (vo.getBaselAssetClass().equals("BS") && vo.getBs_obs_otc().equals("OBS")
					&& vo.getRiskWeight().equals("0")) {

				sumList = map.get("BS_OBS_0");
				
				if(sumList.getSumNotationalAmount() == null) {
					sumList.setSumNotationalAmount(vo.getNotationalAmount());
				}	else {
					sumList.setSumNotationalAmount(vo.getNotationalAmount() + sumList.getSumNotationalAmount());
				}
				
				if(sumList.getSumPreMitigationAmount()==null) {
					sumList.setSumPreMitigationAmount(vo.getPremitigationEAD());
				} else {
					sumList.setSumPreMitigationAmount(vo.getPremitigationEAD() + sumList.getSumPreMitigationAmount());
				}

				map.put("BS_OBS_0", sumList);

			}

			if (vo.getBaselAssetClass().equals("BS") && vo.getBs_obs_otc().equals("OBS")
					&& vo.getRiskWeight().equals("20")) {

				sumList = map.get("BS_OBS_20");
				if(sumList.getSumNotationalAmount() == null) {
					sumList.setSumNotationalAmount(vo.getNotationalAmount());
				}	else {
					sumList.setSumNotationalAmount(vo.getNotationalAmount() + sumList.getSumNotationalAmount());
				}
				
				if(sumList.getSumPreMitigationAmount()==null) {
					sumList.setSumPreMitigationAmount(vo.getPremitigationEAD());
				} else {
					sumList.setSumPreMitigationAmount(vo.getPremitigationEAD() + sumList.getSumPreMitigationAmount());
				}
				map.put("PSE_OBS_20", sumList);

			}

			if (vo.getBaselAssetClass().equals("BS") && vo.getBs_obs_otc().equals("OTC")
					&& vo.getRiskWeight().equals("0")) {

				sumList = map.get("BS_OTC_0");
				if(sumList.getSumNotationalAmount() == null) {
					sumList.setSumNotationalAmount(vo.getNotationalAmount());
				}	else {
					sumList.setSumNotationalAmount(vo.getNotationalAmount() + sumList.getSumNotationalAmount());
				}
				
				if(sumList.getSumPreMitigationAmount()==null) {
					sumList.setSumPreMitigationAmount(vo.getPremitigationEAD());
				} else {
					sumList.setSumPreMitigationAmount(vo.getPremitigationEAD() + sumList.getSumPreMitigationAmount());
				}
				
				
				sumlist.setNetExposure(sumlist.getSumPreMitigationAmount() -  sumList.getUncoveredAmount());
				
				map.put("BS_OTC_0", sumList);

			}

			if (vo.getBaselAssetClass().equals("BS") && vo.getBs_obs_otc().equals("OTC")
					&& vo.getRiskWeight().equals("20")) {

				sumList = map.get("BS_OTC_20");
				
				if(sumList.getSumNotationalAmount() == null) {
					sumList.setSumNotationalAmount(vo.getNotationalAmount());
				}	else {
					sumList.setSumNotationalAmount(vo.getNotationalAmount() + sumList.getSumNotationalAmount());
				}
				
				if(sumList.getSumPreMitigationAmount()==null) {
					sumList.setSumPreMitigationAmount(vo.getPremitigationEAD());
				} else {
					sumList.setSumPreMitigationAmount(vo.getPremitigationEAD() + sumList.getSumPreMitigationAmount());
				}

				map.put("BS_OTC_20", sumList);

			}

		}

		// Calculate subtotal for each category
		Map<String, SumListSubTotal> mapSubTotal = CreditRWAProcessorSubTotal.calculateSubTotal(map);
		
		// Calculate total for each BaselAssetClass
		Map<String, BaselAssetClass> mapBaselAssetClass = CreditRWAProcessorBaselAssetClassFinal.calculateSubTotalFinal(mapSubTotal);
		
		CreditRWATotal creditRWATotal = new CreditRWATotal();
		
		Iterator<Map.Entry<String, BaselAssetClass>> baselAssetClassMapItr = mapBaselAssetClass.entrySet().iterator();
		
		while(baselAssetClassMapItr.hasNext()) {
			
			Map.Entry<String, BaselAssetClass> entry = baselAssetClassMapItr.next();
			
			BaselAssetClass baselAssetClass = entry.getValue();
			
			if(creditRWATotal.getCreditRWANotionalAmount()!=null) {
				creditRWATotal.setCreditRWANotionalAmount(creditRWATotal.getCreditRWANotionalAmount() + baselAssetClass.getSumNotationalAmountFinal());
			}
			else {
				creditRWATotal.setCreditRWANotionalAmount(baselAssetClass.getSumNotationalAmountFinal());
			}
			
			
			
		}
	}

}
