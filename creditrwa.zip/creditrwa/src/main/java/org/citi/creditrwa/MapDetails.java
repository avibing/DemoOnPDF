package org.citi.creditrwa;

import java.util.HashMap;
import java.util.Map;

public class MapDetails {

	public static Map<String, SumList> getSubListMap(){
		Map<String, SumList> map = new HashMap<String, SumList>();
		
		map.put("BS_OBS_0", new SumList());
		map.put("BS_OBS_20", new SumList());
		map.put("BS_OBS_50", new SumList());
		map.put("BS_OBS_100", new SumList());
		
		map.put("BS_OTC_0", new SumList());
		map.put("BS_OTC_20", new SumList());
		map.put("BS_OTC_50", new SumList());
		map.put("BS_OTC_100", new SumList());
		
		
		return map;
	}
	
	public static Map<String, SumListSubTotal> getSumListSubTotalMap(){
		Map<String, SumListSubTotal> map = new HashMap<String, SumListSubTotal>();
		
		map.put("BS_OBS", new SumListSubTotal());
		map.put("BS_OTC", new SumListSubTotal());
		
		return map;
	}
	
	public static Map<String, BaselAssetClass> getBaselAssetClassMap(){
		Map<String, BaselAssetClass> map = new HashMap<String, BaselAssetClass>();
		
		map.put("BS", new BaselAssetClass());
		map.put("OtherBaselAssetClass", new BaselAssetClass());
		
		return map;
	}
}
