package org.citi.creditrwa;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

public class CreditRWAProcessorSubTotal {

	public static Map<String, SumListSubTotal> calculateSubTotal(Map<String, SumList> map) {
		
		Map<String, SumListSubTotal> mapSubTotal = new HashMap<String, SumListSubTotal>();
		
		SumListSubTotal subListSubTotal = new SumListSubTotal();
		
		Iterator<Map.Entry<String, SumList>> itr = map.entrySet().iterator();
		
		while(itr.hasNext()) {
			
			Map.Entry<String, SumList> entry = itr.next();
			String key = entry.getKey();
			SumList sumList = entry.getValue();
			
			if(key.contains("BS_OBS")) {
				
				subListSubTotal = mapSubTotal.get("BS_OBS");
				if(subListSubTotal.getSumNotationalAmountSubTotal()==null) {
					subListSubTotal.setSumNotationalAmountSubTotal(sumList.getSumNotationalAmount()	);
				}else {
					subListSubTotal.setSumNotationalAmountSubTotal(
							subListSubTotal.getSumNotationalAmountSubTotal() + sumList.getSumNotationalAmount()	);
				}
				mapSubTotal.put("BS_OBS", subListSubTotal);
			}
			
			if(key.contains("BS_OTC")) {
				
				subListSubTotal = mapSubTotal.get("BS_OTC");
				if(subListSubTotal.getSumNotationalAmountSubTotal()==null) {
					subListSubTotal.setSumNotationalAmountSubTotal(sumList.getSumNotationalAmount()	);
				}else {
					subListSubTotal.setSumNotationalAmountSubTotal(
							subListSubTotal.getSumNotationalAmountSubTotal() + sumList.getSumNotationalAmount()	);
				}
				mapSubTotal.put("BS_OTC", subListSubTotal);
			}
		}
		
		return mapSubTotal;
		
	}
	
}
