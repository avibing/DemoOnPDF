package org.citi.creditrwa;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

public class CreditRWAProcessorBaselAssetClassFinal {

	public static Map<String, BaselAssetClass> calculateSubTotalFinal(Map<String, SumListSubTotal> mapSubTotal) {
		
		Map<String, BaselAssetClass> mapBaselAssetClass = new HashMap<String, BaselAssetClass>();
		
		BaselAssetClass baselAssetClass = new BaselAssetClass();
		
		Iterator<Map.Entry<String, SumListSubTotal>> itr = mapSubTotal.entrySet().iterator();
		
		while(itr.hasNext()) {
			
			Map.Entry<String, SumListSubTotal> entry = itr.next();
			String key = entry.getKey();
			SumListSubTotal sumList = entry.getValue();
			
			if(key.contains("BS")) {
				
				baselAssetClass = mapBaselAssetClass.get("BS");
				if(baselAssetClass.getSumNotationalAmountFinal()==null) {
					baselAssetClass.setSumNotationalAmountFinal(sumList.getSumNotationalAmountSubTotal());
				}else {
					baselAssetClass.setSumNotationalAmountFinal(
							baselAssetClass.getSumNotationalAmountFinal() + sumList.getSumNotationalAmountSubTotal());
				}
				mapBaselAssetClass.put("BS", baselAssetClass);
				
			}
			
			if(key.contains("BS")) {
				
				baselAssetClass = mapBaselAssetClass.get("BS");
				if(baselAssetClass.getSumNotationalAmountFinal()==null) {
					baselAssetClass.setSumNotationalAmountFinal(sumList.getSumNotationalAmountSubTotal());
				}else {
					baselAssetClass.setSumNotationalAmountFinal(
							baselAssetClass.getSumNotationalAmountFinal() + sumList.getSumNotationalAmountSubTotal());
				}
				mapBaselAssetClass.put("BS", baselAssetClass);
				
			}
			
		}
		
		return mapBaselAssetClass;
	}
	
}
