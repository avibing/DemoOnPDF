package org.citi.creditrwa;

public class CreditRWATotal {

	public String creditRWANotionalAmount;
	
	public String creditRWAPreMitigationAmount;
	
	public String creditRWAUnCoveredAmount;


	
	public String getCreditRWANotionalAmount() {
		return creditRWANotionalAmount;
	}

	public void setCreditRWANotionalAmount(String creditRWANotionalAmount) {
		this.creditRWANotionalAmount = creditRWANotionalAmount;
	}

	public String getCreditRWAPreMitigationAmount() {
		return creditRWAPreMitigationAmount;
	}

	public void setCreditRWAPreMitigationAmount(String creditRWAPreMitigationAmount) {
		this.creditRWAPreMitigationAmount = creditRWAPreMitigationAmount;
	}

	public String getCreditRWAUnCoveredAmount() {
		return creditRWAUnCoveredAmount;
	}

	public void setCreditRWAUnCoveredAmount(String creditRWAUnCoveredAmount) {
		this.creditRWAUnCoveredAmount = creditRWAUnCoveredAmount;
	}
		
}
