package org.citi.creditrwa;

public class SumListSubTotal {

	String sumNotationalAmountSubTotal;
	String sumPreMitigationAmountSubTotal;

	public String getSumNotationalAmountSubTotal() {
		return sumNotationalAmountSubTotal;
	}

	public void setSumNotationalAmountSubTotal(String sumNotationalAmountSubTotal) {
		this.sumNotationalAmountSubTotal = sumNotationalAmountSubTotal;
	}

	public String getSumPreMitigationAmountSubTotal() {
		return sumPreMitigationAmountSubTotal;
	}

	public void setSumPreMitigationAmountSubTotal(String sumPreMitigationAmountSubTotal) {
		this.sumPreMitigationAmountSubTotal = sumPreMitigationAmountSubTotal;
	}

}
